module.exports = {
  attributes: {
    
      tag: {
        type: Sequelize.STRING(32),
        allowNull: false,
        
        
      },
  
  },
  associations: () => {},
  options: {
    classMethods: {},
    instanceMethods: {},
    hooks: {}
  }
};
